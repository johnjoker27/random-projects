#include <iostream>
#include <string>
#include <vector>
#include <fstream>

#include "Student.h"

using namespace std;

int main()
{
    vector <Student<double>> students;
    int choice;

    do
    {
       cout << "\n ===================================== \n" ;
       cout << "WELCOME TO THE STUDENT MANAGEMENT SYSTEM WE BUILT :)";
       cout <<"\n ============================================ \n " ;
       cout << "Make your choice: " << endl;
       cout << "1. Add student and marks. " << endl;
       cout << "2. Display the stored student and marks. " <<endl;
       cout << "3. Choose this option if you want to leave this beautiful program. " << endl;
       cout << "4. Show other saved info... " << endl;
       cout << "The choice is yours: " << endl;
       cin >> choice;


       switch(choice)
       {
       case 1:
           {
               Student<double> s;
           cout << "\n================================\n";
           s.inputInfo();
           students.push_back(s);
           s.saveStudInfoToFile();
           cout << "Student added successfully......" << endl;
            break;
           }
       case 2:
           {
               cout << "\n===================================\n";
           if(students.empty())
           {
               cout << "You are yet to input any information for the students you seek...." << endl;
               cout << "Please choose option one to do that...." << endl;
           }
           else
           {
               for (  auto &student : students)
               {

                   student.display();
                   cout << "\n======================================\n";
               }
           }

        break;
           }
       case 3:
        {
            cout << " \nEXITING ....... GOODDAY \n" << endl;
        break;
        }
       case 4:
        {
            Student<double> s;
            cout << "Showing previously saved info :......" << endl;
            s.printFromFile();
            break;
        }
       default:
           {
            cout << "Invalid input..." << endl;
           }



       }
    }

    while (choice != 3);


    return 0;
}
