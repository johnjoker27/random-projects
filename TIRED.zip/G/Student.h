#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <iostream>
#include <limits>
#include <fstream>

using namespace std;

template < typename T >
class Student
{
private:
    string name;
    int id;
    string program;
    int level;
    T assignment_marks;
    T midSem_marks;
    T endOfSem_marks;

    template<typename U>
    void inputNumber(const string &prompt, U &int_value)
    {
        while(true)
        {
            cout << prompt;

            if(cin >> int_value)
                return;

            cout << "Invalid input. Please make sure the numbers entered are actually numbers.\n" << endl;

            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(),'\n');
        }
    }

public:
    Student()
    {
        name = "";
    id = 0;
    program = "";
    level = 0;
    assignment_marks = 0;
    midSem_marks = 0;
    endOfSem_marks = 0;
    }

    Student(string nom, int identity, string degree, int yr, T assignment, T midSem, T endSem):
        name(nom),
        id(identity),
        program(degree),
        level(yr),
        assignment_marks(assignment),
        midSem_marks(midSem),
        endOfSem_marks(endSem)
        {}


        void setName( string nom)
        {
            name = nom;
        }

        void setId(int identity)
        {
            id = identity;
        }

        void setProgram(string degree)
        {
            program = degree;
        }

        void setLevel(int yr)
        {
            level = yr;
        }

        void setAssignmentMarks(T assignment)
        {
            assignment_marks = assignment;
        }

        void setMidSemMarks(T midSem)
        {
            midSem_marks = midSem;
        }

        void setEndOfSemMarks(T endSem)
        {
            endOfSem_marks = endSem;
        }




        string getName()
        {
            return name;
        }

        int getId()
        {
            return id;
        }

        string getProgram()
        {
            return program;
        }

        int getLevel()
        {
            return level;
        }

        T getAssignmentMarks()
        {
            return assignment_marks;
        }

        T getMidSemMarks()
        {
            return midSem_marks;
        }

        T getEndOfSemMarks()
        {
            return endOfSem_marks;
        }


        void inputInfo()
        {
            string nom;
            int identity;
            int yr;
            string degree;
            T assignment;
            T midSem;
            T EndSem;
            cout << "Enter the following info: " << endl;

            cout << "Student Name: ";
            getline(cin >> ws, nom);
            setName(nom);

            inputNumber("Student Id: ", identity);
            setId(identity);

            inputNumber("Level: ",yr);
            setLevel(yr);

            cout <<"\nProgram: ";
            getline(cin >> ws, degree);
            setProgram(degree);

            inputNumber("Assignment marks: ", assignment);
            setAssignmentMarks(assignment);

            inputNumber("Mid Sem marks: ", midSem);
            setMidSemMarks(midSem);

            inputNumber("End of Sem marks: ", EndSem);
            setEndOfSemMarks(EndSem);
        }

        double calculateWeightedAverage() const
        {
            return (assignment_marks*0.20 )+ (midSem_marks*0.20) + (endOfSem_marks * 0.60);

        }

        char calculateGrade() const
        {
            double average = calculateWeightedAverage();

            if (average >= 80)
            {
                return 'A';
            }
            else if ( average >= 70)
            {
                return 'B';
            }
            else if ( average >= 60)
            {
                return 'C';
            }
            else if ( average >= 50 )
            {
                return 'D';
            }
            else if ( average >= 40)
            {
                return 'E';
            }
            else
            {
                return 'F';
            }
        }

        void display() const
        {

            cout << "=================================" << endl;
            cout << "Name: " << name << endl;
            cout << "ID: " << id << endl;
            cout << "Program: " << program << endl;
            cout << "Level: " << level << endl;

            cout << "Assignment Grade: " << assignment_marks << endl;
            cout << "Mid Semester Marks: " << midSem_marks << endl;
            cout << "End of Semester Exams: " << endOfSem_marks << endl;

            cout << "Weighted Average: " << calculateWeightedAverage() << endl;
            cout << "Grade: " << calculateGrade() << endl;
        }

        void saveStudInfoToFile()
        {
            ofstream file("student.txt",ios::app);

            if(file.is_open())
            {
                file<< name << endl;
                file << id << endl;
                file << program << endl;
                file << level << endl;
                file << assignment_marks << endl;
                file << midSem_marks << endl;
                file << endOfSem_marks << endl;
                //file << "- - - - - - - - - - - - - -" << endl;

                file.close();
            }
            else
            {
                cout << "File could not be opened or wasn't found ....." << endl;
            }
        }


        void printFromFile()
        {
            ifstream file("student.txt");

            if (!file.is_open())
            {
                cout << "The file could not be opened.." << endl;
            }

            cout << "The program is going to try to show what you saved....." << endl;
            while (getline(file,name))
            {
                getline(file,name);

                file >> id;
                file.ignore();

                getline(file,program);

                file >> level;
                file >> assignment_marks;
                file >> midSem_marks;
                file >> endOfSem_marks;
                file.ignore();

                cout << "==============================================" << endl;
                cout << "Name: " << name << endl;
                cout << "ID : "  << id << endl;
                cout << "Program: " << program << endl;
                cout << "level: " << level << endl;
                cout << "Assignment: " << assignment_marks << endl;
                cout << "Mid Semester Marks: "  << midSem_marks << endl;
                cout << "End of Semester Marks: " << endOfSem_marks << endl;
                cout << "Weighted Average: " << calculateWeightedAverage() << endl;
                cout << "Grade saved: " << calculateGrade() << endl;

                file.close();


            }

        }






};


#endif // STUDENT_H

